public class Main{
    /*
        Name: Ahmed Sayed Hassan Youssef
        ID: 20190034
        Group: G5 G6
    */
    public static void main( String [] args ){
        new ClipsGui();
    }
}